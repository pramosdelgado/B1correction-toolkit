function sp=uplus(sp)
% sympoly/uplus: unary plus for a sympoly object
% usage: sp = +sp;
% 
% arguments:
%  sp - a sympoly object

% its really just a no-op
